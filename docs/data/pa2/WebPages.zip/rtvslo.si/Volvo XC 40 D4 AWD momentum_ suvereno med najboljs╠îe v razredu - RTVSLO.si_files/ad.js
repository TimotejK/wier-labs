(_gdeaq = window._gdeaq || []).push(['nc', 'false']);
(_gdeaq = window._gdeaq || []).push(['gdpr_consent', '']);
if (0) {(_gdeaq = window._gdeaq || []).push(['roc', 'true']);
(_gdeaq = window._gdeaq || []).push(['plain']);
}(_gdeaq = window._gdeaq || []).push(['hit', 'si', 'zIE65jxep7g5Ys46AW8HG7e_Xfa8DC9A8AOKKI7SFEr.u7', 'vodsnugoyd', 'mgbqsovmcqczufgwrffnbdmcynlh']);
if(0){(function() {var s = document.getElementsByTagName("script")[0];var xgde = document.createElement("script");xgde.async = true;xgde.src = "https://si.hit.gemius.pl/gdejs/xgde.js";s.parentNode.insertBefore(xgde, s);})();}else{document.write('<scr' + 'ipt type="text/javascript" src="https://si.hit.gemius.pl/gdejs/xgde.js"> </scr' + 'ipt>');}


document.write("<a target=\"_blank\" href=\"https:\/\/si.hit.gemius.pl\/lshitredir\/id=zIE65jxep7g5Ys46AW8HG7e_Xfa8DC9A8AOKKI7SFEr.u7\/fastid=cfngmhbnctpcdmftgrrpzlfvwnlc\/stparam=kgdmmlphrw\/roc=0\/url=https:\/\/www.oduhljadorepa.com\/?utm_source=rtvslo&utm_medium=banner&utm_campaign=oudr\"><img src=\"https:\/\/sigde.adocean.pl\/files\/akaqknikucm\/rfejpwhsmj\/uberdnjrzu\/Banner-300x250_3.jpg\" width=\"300\" height=\"250\" border=\"0\" \/><\/a>\r\n");
